var struct_d_w_reduced_value =
[
    [ "ave", "struct_d_w_reduced_value.html#a2b5c034442d944f3e3e5611987737cc3", null ],
    [ "max", "struct_d_w_reduced_value.html#af98d5a44c1b776550fb039f9887b9b86", null ],
    [ "min", "struct_d_w_reduced_value.html#a4a3a79763fae1ab017a0dd8084af892b", null ],
    [ "rms", "struct_d_w_reduced_value.html#a6357fb4ab06f544bce12e181d74098a9", null ],
    [ "time_stamp", "struct_d_w_reduced_value.html#aa6f8b3d929654772e5d8443c65de26aa", null ]
];