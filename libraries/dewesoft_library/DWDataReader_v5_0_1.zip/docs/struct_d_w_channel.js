var struct_d_w_channel =
[
    [ "array_size", "struct_d_w_channel.html#ad064be599b15cc12f7e3015d049cd51f", null ],
    [ "color", "struct_d_w_channel.html#adad6ab632f5c6773a8049154b5b3a63c", null ],
    [ "data_type", "struct_d_w_channel.html#a3eb0c6148265843760acd3766dfbf3d0", null ],
    [ "description", "struct_d_w_channel.html#a107022292f24aeea26c01d4c50da0681", null ],
    [ "index", "struct_d_w_channel.html#a5d4eca6e3e6e8963929957447f45e23d", null ],
    [ "name", "struct_d_w_channel.html#ad5cf71ed3d77a23a99b7d488d37021c3", null ],
    [ "unit", "struct_d_w_channel.html#a412f443d64fa594467eb52e16b5a381f", null ]
];