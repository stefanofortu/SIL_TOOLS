var searchData=
[
  ['max_0',['max',['../struct_d_w_reduced_value.html#af98d5a44c1b776550fb039f9887b9b86',1,'DWReducedValue']]],
  ['min_1',['min',['../struct_d_w_reduced_value.html#a4a3a79763fae1ab017a0dd8084af892b',1,'DWReducedValue']]]
];
