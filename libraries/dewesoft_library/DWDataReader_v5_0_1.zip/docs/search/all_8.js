var searchData=
[
  ['name_0',['name',['../struct_d_w_channel.html#ad5cf71ed3d77a23a99b7d488d37021c3',1,'DWChannel::name'],['../struct_d_w_array_info.html#a72c9ace08824c69a783f5fe030d43ac9',1,'DWArrayInfo::name']]]
];
