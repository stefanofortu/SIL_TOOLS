var searchData=
[
  ['unit_0',['unit',['../struct_d_w_channel.html#a412f443d64fa594467eb52e16b5a381f',1,'DWChannel::unit'],['../struct_d_w_array_info.html#ad432da2d210518e07b75173006ba0419',1,'DWArrayInfo::unit']]]
];
