var searchData=
[
  ['re_0',['re',['../struct_d_w_complex.html#a346496423bb40eef30838660600a7212',1,'DWComplex']]],
  ['reader_5fhandle_1',['READER_HANDLE',['../_d_w_data_reader_lib_types_8h.html#ae92841373e64d3aafc6086a454c76dac',1,'DWDataReaderLibTypes.h']]],
  ['rms_2',['rms',['../struct_d_w_reduced_value.html#a6357fb4ab06f544bce12e181d74098a9',1,'DWReducedValue']]]
];
