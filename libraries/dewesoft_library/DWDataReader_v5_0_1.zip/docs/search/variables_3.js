var searchData=
[
  ['event_5ftext_0',['event_text',['../struct_d_w_event.html#a1095b899d2743d66b66718e7b3e1e779',1,'DWEvent']]],
  ['event_5ftype_1',['event_type',['../struct_d_w_event.html#a8258f5d375b58e376801032d11bb9a10',1,'DWEvent']]]
];
