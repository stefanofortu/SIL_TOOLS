var searchData=
[
  ['dwdatareaderlibfuncs_2eh_0',['DWDataReaderLibFuncs.h',['../_d_w_data_reader_lib_funcs_8h.html',1,'']]],
  ['dwdatareaderlibtypes_2eh_1',['DWDataReaderLibTypes.h',['../_d_w_data_reader_lib_types_8h.html',1,'']]]
];
