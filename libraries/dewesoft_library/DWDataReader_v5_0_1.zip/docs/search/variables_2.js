var searchData=
[
  ['data_5ftype_0',['data_type',['../struct_d_w_channel.html#a3eb0c6148265843760acd3766dfbf3d0',1,'DWChannel']]],
  ['description_1',['description',['../struct_d_w_channel.html#a107022292f24aeea26c01d4c50da0681',1,'DWChannel']]],
  ['doubleval_2',['doubleVal',['../struct_d_w_custom_prop.html#a6d51d6fa893a2dc4dbeac1af5e778fcd',1,'DWCustomProp']]],
  ['duration_3',['duration',['../struct_d_w_file_info.html#a9a7f164b8dbccfca87b062b2b2b4c5b6',1,'DWFileInfo::duration'],['../struct_d_w_measurement_info.html#a386dd2160d1776e86f26271596631cf2',1,'DWMeasurementInfo::duration']]]
];
