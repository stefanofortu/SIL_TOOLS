var searchData=
[
  ['time_5fstamp_0',['time_stamp',['../struct_d_w_event.html#a2402814692d461d63dce2c13ffb71847',1,'DWEvent::time_stamp'],['../struct_d_w_reduced_value.html#aa6f8b3d929654772e5d8443c65de26aa',1,'DWReducedValue::time_stamp']]]
];
