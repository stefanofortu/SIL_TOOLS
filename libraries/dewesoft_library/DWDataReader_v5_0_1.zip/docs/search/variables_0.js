var searchData=
[
  ['array_5fsize_0',['array_size',['../struct_d_w_channel.html#ad064be599b15cc12f7e3015d049cd51f',1,'DWChannel']]],
  ['ave_1',['ave',['../struct_d_w_reduced_value.html#a2b5c034442d944f3e3e5611987737cc3',1,'DWReducedValue']]]
];
