var searchData=
[
  ['reader_5fhandle_0',['READER_HANDLE',['../_d_w_data_reader_lib_types_8h.html#ae92841373e64d3aafc6086a454c76dac',1,'DWDataReaderLibTypes.h']]]
];
