var searchData=
[
  ['re_0',['re',['../struct_d_w_complex.html#a346496423bb40eef30838660600a7212',1,'DWComplex']]],
  ['rms_1',['rms',['../struct_d_w_reduced_value.html#a6357fb4ab06f544bce12e181d74098a9',1,'DWReducedValue']]]
];
