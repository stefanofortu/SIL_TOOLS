var searchData=
[
  ['color_0',['color',['../struct_d_w_channel.html#adad6ab632f5c6773a8049154b5b3a63c',1,'DWChannel']]]
];
