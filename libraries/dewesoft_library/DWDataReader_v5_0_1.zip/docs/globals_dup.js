var globals_dup =
[
    [ "d", "globals.html", null ],
    [ "e", "globals_e.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ]
];