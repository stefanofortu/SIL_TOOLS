var struct_d_w_custom_prop =
[
    [ "doubleVal", "struct_d_w_custom_prop.html#a6d51d6fa893a2dc4dbeac1af5e778fcd", null ],
    [ "int64Val", "struct_d_w_custom_prop.html#a49a52fa81b1f8408242df452d51d80a6", null ],
    [ "key", "struct_d_w_custom_prop.html#a050c3d7793e9208caeefbb35de043f01", null ],
    [ "strVal", "struct_d_w_custom_prop.html#a958bcbfe63cfc71dcf755174b0b34e7d", null ],
    [ "valueType", "struct_d_w_custom_prop.html#a2b3053e97c21c86e329d69c067c7aacf", null ]
];