var struct_d_w_array_info =
[
    [ "index", "struct_d_w_array_info.html#a2da197e8aee29aae7c4e5e20a7c73363", null ],
    [ "name", "struct_d_w_array_info.html#a72c9ace08824c69a783f5fe030d43ac9", null ],
    [ "size", "struct_d_w_array_info.html#a237f830d04ad00e51c52da94535b713d", null ],
    [ "unit", "struct_d_w_array_info.html#ad432da2d210518e07b75173006ba0419", null ]
];