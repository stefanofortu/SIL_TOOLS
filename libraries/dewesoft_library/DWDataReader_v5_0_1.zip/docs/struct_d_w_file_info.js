var struct_d_w_file_info =
[
    [ "duration", "struct_d_w_file_info.html#a9a7f164b8dbccfca87b062b2b2b4c5b6", null ],
    [ "sample_rate", "struct_d_w_file_info.html#a1c6e6e5d0c022b459c761029cd3c01a4", null ],
    [ "start_store_time", "struct_d_w_file_info.html#a208793c1ccc096d46e5ee1ec4f6e92b0", null ]
];