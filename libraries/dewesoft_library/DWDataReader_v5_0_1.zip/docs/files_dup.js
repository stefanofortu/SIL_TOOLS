var files_dup =
[
    [ "datareaderlib", "dir_4df9e2c1cd05dde26086022037a63802.html", "dir_4df9e2c1cd05dde26086022037a63802" ]
];