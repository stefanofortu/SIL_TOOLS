var struct_d_w_complex =
[
    [ "im", "struct_d_w_complex.html#a69055d611883d97edb0d28449c001575", null ],
    [ "re", "struct_d_w_complex.html#a346496423bb40eef30838660600a7212", null ]
];