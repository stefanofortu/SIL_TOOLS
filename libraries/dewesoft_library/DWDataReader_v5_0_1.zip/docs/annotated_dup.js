var annotated_dup =
[
    [ "DWArrayInfo", "struct_d_w_array_info.html", "struct_d_w_array_info" ],
    [ "DWBinarySample", "struct_d_w_binary_sample.html", null ],
    [ "DWChannel", "struct_d_w_channel.html", "struct_d_w_channel" ],
    [ "DWComplex", "struct_d_w_complex.html", "struct_d_w_complex" ],
    [ "DWCustomProp", "struct_d_w_custom_prop.html", "struct_d_w_custom_prop" ],
    [ "DWEvent", "struct_d_w_event.html", "struct_d_w_event" ],
    [ "DWFileInfo", "struct_d_w_file_info.html", "struct_d_w_file_info" ],
    [ "DWMeasurementInfo", "struct_d_w_measurement_info.html", "struct_d_w_measurement_info" ],
    [ "DWReducedValue", "struct_d_w_reduced_value.html", "struct_d_w_reduced_value" ]
];