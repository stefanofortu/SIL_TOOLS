var struct_d_w_measurement_info =
[
    [ "duration", "struct_d_w_measurement_info.html#a386dd2160d1776e86f26271596631cf2", null ],
    [ "sample_rate", "struct_d_w_measurement_info.html#a0064d0689c8261ca328a899eacdbd2ea", null ],
    [ "start_measure_time", "struct_d_w_measurement_info.html#ab7896de59b68af734a633df68049ba83", null ],
    [ "start_store_time", "struct_d_w_measurement_info.html#a37fedbc7e320847c5639cc100daaed86", null ]
];